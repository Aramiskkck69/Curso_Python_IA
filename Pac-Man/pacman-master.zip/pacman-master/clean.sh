#!/bin/bash
rm *.pyc
