#!/bin/bash
python gridworld.py -a q -k 100 -m -n 0
