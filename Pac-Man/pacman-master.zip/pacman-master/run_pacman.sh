#!/bin/bash
python pacman.py -p ApproximateQAgent -a extractor=SimpleExtractor -l mediumClassic --ghosts KeyboardGhost --numghosts 2 --gameMenu --zoom 1
